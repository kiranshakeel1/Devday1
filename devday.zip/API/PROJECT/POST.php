<?php 

    include_once("../connection.php");

    $p_name = $_POST['p_name'];
    $p_key = rand(1,1111111)*9;
    $c_role = $_POST['p_role'];

    if(mysqli_query($conn,"INSERT INTO `project`(`project_key`, `project_name`, `creator_role`) VALUES ('$p_key','$p_name','$c_role')")){
        echo "New Project Has Been Created";
    }else{
        echo "Something Went Wrong!";
    }

?>