<?php
    include_once("../connection.php");

    $u_id = $_POST['u_id'];

    $query = " SELECT * FROM `project` WHERE `creator_role` = '$u_id' ORDER BY id DESC ";
    $query = mysqli_query($conn, $query);

    if($query){
        $items = array();

        while($item = mysqli_fetch_assoc($query)){

            array_push($items, array(
                "id"=>$item['id'],
                "key"=>$item["project_key"],
                "title"=>$item["project_name"],
            ));

        }
        echo json_encode($items);
    }
?>