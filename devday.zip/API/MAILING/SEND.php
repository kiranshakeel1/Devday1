<?php 

    include_once("../connection.php");

    $mail = $_POST['mail'];
    $p_key = $_POST['key'];


    if(mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM `users` WHERE `email` = '".$mail."'"))){


        $to = $mail;
        $subject = "Invitation of Project Link";
         
        $message = "You are invited in a project for which key is: ".$p_key;
        // $message .= "";
         
        $header = "From:abc@somedomain.com \r\n";
        $header .= "Cc:afgh@somedomain.com \r\n";
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-type: text/html\r\n";
         
        // $retval = mail($to,$subject,$message,$header);
        if(mail($to,$subject,$message,$header)){
            echo "Your invitation has been sent";
        }else{
            echo "Something went wrong";
        }

    }else{
        echo "Not a user";
    }


    // if(mysqli_query($conn,"INSERT INTO `tasks`( `task_title`, `task_desc`, `project_id`, `task_status`) VALUES ('$t_title','$t_desc','$p_id','0')")){
    //     echo "New Task Has Been Created";
    // }else{
    //     echo "Something Went Wrong!";
    // }

?>