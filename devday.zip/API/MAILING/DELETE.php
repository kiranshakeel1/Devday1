<?php 

    include_once("../connection.php");

    $u_id = $_POST['u_id'];

    if(mysqli_query($conn,"DELETE FROM `members` WHERE `id` = '$u_id'")){
        echo "Member Has Been Removed";
    }else{
        echo "Something Went Wrong!";
    }

?>