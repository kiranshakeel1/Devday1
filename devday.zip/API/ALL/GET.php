<?php
    include_once("../connection.php");

    $u_id = $_POST['u_id'];

    $query = " SELECT * FROM `members` WHERE `u_id` = '$u_id' ORDER BY id DESC ";
    $query = mysqli_query($conn, $query);

    if($query){
        $items = array();

        while($item = mysqli_fetch_assoc($query)){

            $proj = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM `project` WHERE `id` = '".$item['p_id']."'"));

            array_push($items, array(
                "id"=>$proj['id'],
                "key"=>$proj["project_key"],
                "title"=>$proj["project_name"],
            ));

        }
        echo json_encode($items);
    }
?>