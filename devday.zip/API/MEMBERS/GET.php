<?php
    include_once("../connection.php");

    $p_id = $_POST['p_id'];

    $query = " SELECT * FROM `members` WHERE `p_id` = '$p_id' ORDER BY id DESC ";
    $query = mysqli_query($conn, $query);

    if($query){
        $items = array();

        while($item = mysqli_fetch_assoc($query)){

            $user = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '".$item['u_id']."'"));

            array_push($items, array(
                "id"=>$item['id'],
                "u_id"=>$user['f_name']." ".$user["l_name"],
            ));

        }
        echo json_encode($items);
    }
?>