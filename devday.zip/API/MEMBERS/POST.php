<?php 

    include_once("../connection.php");

    $u_id = $_POST['u_id'];
    $p_key = $_POST['p_key'];

    $keyProj = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `project` WHERE `project_key` = '$p_key'"));

    if( !(mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `members` WHERE `p_id` = '".$keyProj['id']."' && `u_id` = '$u_id' "))) ){    

        if(mysqli_query($conn,"INSERT INTO `members`(`u_id`, `p_id`) VALUES ('$u_id','".$keyProj['id']."')")){
            echo "You have successfully joined project '".$keyProj['project_name']."'";
        }else{
            echo "Something Went Wrong!";
        }
    
    }else{

        echo "You are already a member of this project";

    }

?>