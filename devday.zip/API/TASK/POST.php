<?php 

    include_once("../connection.php");

    $t_title = $_POST['t_name'];
    $t_desc = $_POST['t_desc'];
    $p_id = $_POST['p_id'];

    if(mysqli_query($conn,"INSERT INTO `tasks`( `task_title`, `task_desc`, `project_id`, `task_status`) VALUES ('$t_title','$t_desc','$p_id','0')")){
        echo "New Task Has Been Created";
    }else{
        echo "Something Went Wrong!";
    }

?>