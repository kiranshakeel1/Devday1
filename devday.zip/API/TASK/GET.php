<?php
    include_once("../connection.php");

    $p_id = $_POST['p_id'];

    $query = " SELECT * FROM `tasks` WHERE `project_id` = '$p_id' ORDER BY id DESC ";
    $query = mysqli_query($conn, $query);

    if($query){
        $items = array();

        while($item = mysqli_fetch_assoc($query)){

            array_push($items, array(
                "id"=>$item['id'],
                "title"=>$item["task_title"],
                "desc"=>$item["task_desc"],
                "status"=>$item["task_status"],
            ));

        }
        echo json_encode($items);
    }
?>