<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/global.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="assets/css/global.css">
</head>
<body>
    <script>
        const page = 0;
    </script>
    
    <?php include_once("assets/components/header.php"); ?>
    
    <main>

        <h1>My Projects</h1>

        <table id="myTable" class="display">

            <thead>

                <tr>
                    <th>S.No</th>
                    <th>Project Key</th>
                    <th>Project Title</th>
                    <th>Project Members</th>
                    <th></th>
                </tr>

            </thead>

            <tbody id="getProjs">

                <!-- Get projects here -->

            </tbody>
        </table>



        

        <div class="seemorebtn">
            <button>See All Projects</button>
            <button onclick="addProj()">Add New Project</button>
        </div>

    </main>

    
    <!-- <div class="modale_cover" id="closeAnyhow"></div> -->

    <div class="dialogbox addProj">
        <h3>New Project</h3>
        <input type="text" placeholder="Project Name" id="projecttitle" style="width: 80%; position: relative; left: 10%; border: none; height: 30px; margin: 5px 0; border-radius:4px;">
        <div class="dialogbox_buttons">
            <button onclick="addproject()">ADD</button>
            <button id="closeMod">CANCEL</button>
        </div>
    </div>




</body>
<script>

    // var u_id = "";

    $(document).ready(function(){
        $('#myTable').DataTable();
    });

    function addProj(){
        $(".addProj, .modale_cover").css("display","inline");
    }
    $("#closeMod").click(function(){
        $(".addProj, .modale_cover").css("display","none");
    });


    function getProjects(){
        document.getElementById("getProjs").innerHTML = ``;
        let sno = 0;
        $.ajax({
            type: 'POST',
            url: '../API/PROJECT/GET.php',
            data: {
                u_id: u_id
            },
            success: function (response) {
                
                response = JSON.parse(response);
                console.log(response);

                for(var items of response){
                    sno++;
                    document.getElementById("getProjs").innerHTML += `
                        <tr style="text-align: center">
                            <td>${sno}</td>
                            <td>${items.key}</td>
                            <td>${items.title}</td>
                            <td>1</td>
                            <td>
                                <button style="padding:5px 10px;" onclick="location.href='project_detail.php?id=${items.id}'">Open Project</button>
                            </td>
                        </tr>
                    `;
                }
            },
        })
    }
    getProjects();


    function addproject(userId = u_id){
        var p_title = $("#projecttitle").val();
        if( !(p_title == "") ){
            $.ajax({
                type: 'POST',
                url: '../API/PROJECT/POST.php',
                data: {
                    p_name: p_title,
                    p_role: userId
                },
                success: function (response) {
                    getProjects();
                    alert(response);
                    $(".dialogbox, .modale_cover").css("display","none");
                },
            });
        }else{
            alert("Can't leave the Project Name Blank");
        }
    }


</script>
</html>