<?php

    include_once("../API/connection.php");

    if(isset($_POST['signin'])){

        $email = $_POST['mail'];
        $passw = $_POST['pass'];

        if($user = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `users` WHERE `email` = '$email' && `password` = '$passw'"))){
            echo $user['id'];
            setcookie('log',$user['id'],time()+(60*60*24*7));
            header("location:index.php");
        }else{
            header("location:login.php?warning=0");
        }

    }


    if(isset($_POST['signup'])){

        $fname = $_POST['f_name'];
        $lname = $_POST['l_name'];
        $email = $_POST['mail'];
        $passw = $_POST['pass'];

        if(mysqli_query($conn, "INSERT INTO `users`( `f_name`, `l_name`, `email`, `password`, `u_img`, `role`) VALUES ('$fname','$lname','$email','$passw','','0')")){
            header("location: login.php?warning=1");
        }




    }


    if(isset($_GET['logout'])){
        setcookie('log',0,time()+(60*60*24*7));
        header("location: login.php");
    }


?>