<?php
    // include_once("auth.php");
    if($_COOKIE['log'] != 0){
        header("location:index.php");
    }

    if(isset($_GET['warning']) && $_GET['warning'] == 0 ){
    ?>
    
        <script>
            alert("You've Entered Wrong Email Or Password");
        </script>        
        
    <?php
    }else if(isset($_GET['warning']) && $_GET['warning'] == 1 ){
    ?>
    
    <script>
        alert("You've Signed Up!");
    </script>     
        
    <?php
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/global.css">
    <title>Document</title>
</head>
<body>
    
    <div style="
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    ">

        <div class="col-lg-3">
            <form action="login_auth.php" method="POST">
                <!-- Email input -->
                <div class="form-outline mb-4">
                    <input type="email" id="form2Example1" name="mail" class="form-control" required/>
                    <label class="form-label" for="form2Example1">Email address</label>
                </div>

                <!-- Password input -->
                <div class="form-outline mb-4">
                    <input type="password" id="form2Example2" name="pass" class="form-control" required/>
                    <label class="form-label" for="form2Example2">Password</label>
                </div>

                <!-- 2 column grid layout for inline styling -->
                <!-- <div class="row mb-4">
                    <div class="col d-flex justify-content-center">
                        
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="form2Example31" checked />
                        <label class="form-check-label" for="form2Example31"> Remember me </label>
                    </div>
                    </div>

                    <div class="col">
                        
                    <a href="#!">Forgot password?</a>
                    </div>
                </div> -->

                <!-- Submit button -->
                <button type="submit" name="signin" class="btn btn-primary btn-block mb-4">Sign in</button>

                <!-- Register buttons -->
                <div class="text-center">
                    <p>Not a member? <a href="#!" onclick="registerModal()">Register</a></p>
                    <p>or sign up with:</p>
                    <button type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-facebook-f"></i>
                    </button>

                    <button type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-google"></i>
                    </button>

                    <button type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-twitter"></i>
                    </button>

                    <button type="button" class="btn btn-link btn-floating mx-1">
                    <i class="fab fa-github"></i>
                    </button>
                </div>
            </form>

        </div>

    </div>

















    <div class="modale_cover closeAnyhow" id="closeAnyhow"></div>


















    <div class="dialogbox" style="background: white; width: 380px; padding: 10px 15px;">

        <h2>Sign Up Here</h2>
        
        <form action="login_auth.php" method="POST">

            <!-- First name input -->
            <div class="form-outline mb-3">
                <label class="form-label" for="form2Example1">First Name</label>
                <input type="text" id="form2Example1" name="f_name" class="form-control"  required/>
            </div>
            
            <!-- Last name input -->
            <div class="form-outline mb-3">
                <label class="form-label" for="form2Example1">last Name</label>
                <input type="text" id="form2Example1" name="l_name" class="form-control"  required/>
            </div>

            <!-- Email input -->
            <div class="form-outline mb-3">
                <label class="form-label" for="form2Example1">Email address</label>
                <input type="email" id="form2Example1" name="mail" class="form-control" required />
            </div>

            <!-- Password input -->
            <div class="form-outline mb-3">
                <label class="form-label" for="form2Example2">Password</label>
                <input type="password" id="form2Example2" name="pass" class="form-control"  required/>
            </div>

            <!-- Password input -->
            <div class="form-outline mb-5">
                <label class="form-label" for="form2Example2">Choose Avatar</label>
                <input type="file" id="form2Example2" name="img" class="form-control" />
            </div>

            <!-- Submit button -->
            <button type="submit" name="signup" class="btn btn-primary btn-block mb-2">Sign Up</button>

            <!-- Close Modale -->
            <button type="button" name="signin" class="btn btn-primary btn-block mb-4 closeAnyhow ">Cancel</button>
        </form>


    </div>


  
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>

    <script>
        // $(".dialogbox").css("display","inline");

        function registerModal(){
            $(".modale_cover, .dialogbox").css("display","inline");

        }

        $(".closeAnyhow").click(()=>{
            $(".modale_cover, .dialogbox").css("display","none");
        })


    </script>

</body>
</html>