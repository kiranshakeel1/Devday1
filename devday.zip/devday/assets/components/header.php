<?php
    include_once("auth.php");
    $user_info = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '".$_COOKIE['log']."'"));
?>

<!-- Header Style -->
<link rel="stylesheet" href="assets/css/header.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">

<!-- Header Content -->
<header>
    <nav>
        <div class="leftside">
            <div id="menuToggle"></div>
            <div class="logo">Management</div>
        </div>

        <div class="status_container">
            <div class="status">
                <div class="useroptions" id="usertoggle"><?php echo $user_info['f_name']." ".$user_info['l_name']; ?></div>
                <div class="useroptions">Profile</div>
                <div class="useroptions" id="logout">Logout</div>
            </div>
        </div>


    </nav>
    <menu>
        <a href="index.php">
            <div class="sidemenuops">Dashboard</div>
        </a>
        <a href="projects.php">
            <div class="sidemenuops">My Projects</div>
        </a>
        <a href="allprojects.php">
            <div class="sidemenuops">Projects</div>
        </a>
        <a href="#" onclick="showJoin()">
            <div class="sidemenuops">Join Project</div>
        </a>
        <!-- <a href="users.php">
            <div class="sidemenuops">Members</div>
        </a> -->
        <a href="setting.php">
            <div class="sidemenuops">Settings</div>
        </a>
    </menu>
</header>



<div class="modale_cover" id="closeAnyhow"></div>

<div class="dialogbox logoutbox">
    <h2>Are you Sure?</h2>
    <div class="dialogbox_buttons">
        <button onclick="logout()">LOGOUT</button>
        <button id="closeMod">CANCEL</button>
    </div>
</div>

<div class="dialogbox joinbox" style="display: none">
    <h2>Join A Project</h2>

    <input type="number" id="p_join_key" placeholder="Project Key" style="text-align: center; width: calc( 90% - 4px ); border:2px solid Grey; position: relative; left: 5%; height:25px; border-radius: 10px;" >
    
    <div class="dialogbox_buttons">
        <button onclick="joinproject()">JOIN</button>
        <button id="closeMod">CANCEL</button>
    </div>

</div>


<!-- Header Functionality -->
<script src="assets/js/header.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script>
    var u_id = <?php echo $user_info['id']; ?>;
    // alert(u_id);
    

    function joinproject(){
        
        var key = $("#p_join_key").val();

        $.ajax({
            type: 'POST',
            url: '../API/MEMBERS/POST.php',
            data: {
                u_id: u_id,
                p_key: key,
            },
            success: function (response) {    
                if(page==1){
                    getProjects();
                }
                alert(response);
                $(".dialogbox, .modale_cover").css("display","none");
            },
        });

    }


</script>