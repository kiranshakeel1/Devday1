$("#usertoggle").on("click",()=>{
    if( !( $(".status").css("height") == "90px" ) ){
        $(".status").css("height","90px");
    }else{
        $(".status").css("height","25px");
    }
})


$("#menuToggle").on("click",()=>{
    if( !($("header menu").css("left") == "0px") ){
        $("header menu").css("left","0px");
    }else{
        $("header menu").css("left","-250px");
    }
})

$(window).resize(()=>{
    
    if($(window).width()>1000){
        $("header menu").css("left","0px");
    }else{
        $("header menu").css("left","-250px");
    }

})

$("#logout").click(()=>{
    $(".logoutbox, .modale_cover").css("display","inline");
    $(".status").css("height","25px");
})

$("#closeAnyhow, #closeMod").click(()=>{
    $(".modale_cover").css("display","none");
    $(".dialogbox").css("display","none");
})


function logout(){
    location.href="login_auth.php?logout";
}

function showJoin(){
    $(".joinbox, .modale_cover").css("display","inline");
}