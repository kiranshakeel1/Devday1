<?php

if( !(isset($_COOKIE['log'])) ){

    setcookie('log',0,time()+(60*60*24*7));
    header("location:index.php");

}else{
    if($_COOKIE['log'] == 0 ){
        header("location:login.php");
    }
}


include_once("../API/connection.php");

?>