<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/global.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="assets/css/global.css">
</head>
<body>
    <script>
        const page = 0;
    </script>
    
    <?php include_once("assets/components/header.php"); 
    $getInfo = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM `project` WHERE `id` = '".$_GET['id']."'"));
    $getAdmin = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '".$getInfo['creator_role']."'" ));

    if( $_COOKIE['log'] == $getInfo['creator_role'] ){
        header("location: index.php");
    }

    ?>

    <script>
        var projectId = "<?php echo $getInfo['id']; ?>";
        // alert(projectId);
    </script>
    
    <main>




        <h1>Project Info</h1>
        <p style="text-align: center; margin-top:5px;"><span style=" font-weight: bold">Project Title:</span> <?php echo $getInfo['project_name']; ?></p>
        <p style="text-align: center; margin-top:5px;"><span style=" font-weight: bold">Project Key:</span> <?php echo $getInfo['project_key']; ?></p>

        <br><br>
        
        <div class="seemorebtn">
            <button onclick="seemembers()">See Members</button>
        </div>

        <br><br><br>

        
        <h1>Tasks on Hand</h1>

        <table id="myTable" class="display">

            <thead>

                <tr>
                    <th>S.No</th>
                    <th>Task Title</th>
                    <th>Task Description</th>
                    <th>Task Status</th>
                    <!-- <th>Project Members</th> -->
                    <th></th>
                </tr>

            </thead>

            <tbody id="getProjs">

                <!-- Get projects here -->

            </tbody>
        </table>



        


    </main>

    

<div class="dialogbox seeMembers" style="display: inline;width:350px;padding: 0px; background: white; display: none" >
    <h3>Project Members</h3>

    <div style="height:400px; overflow-x: hidden; overflow-y: scroll;">

        <div style="width: 100%; background-color:#FAFAFA; line-height:15px; padding: 5px 15px; font-size: 70%; font-weight: bold; text-transform: uppercase; color:#666">Admin</div>

        <div style="width:100%; padding: 15px 10px; line-height: 25px;"><?php echo $getAdmin['f_name']." ".$getAdmin['l_name']; ?></div>
        
        <div style="width: 100%; background-color:#FAFAFA; line-height:15px; padding: 5px 15px; font-size: 70%; font-weight: bold; text-transform: uppercase; color:#666">Members</div>
        
        <span id="getMembersHere">

        
        
        </span>

    </div>

    <div class="dialogbox_buttons">
        <button id="closeMod">CANCEL</button>
    </div>
</div>




</body>
<script>

    $(document).ready(function(){
        $('#myTable').DataTable();
    });

    function addTask(){
        $(".addTask, .modale_cover").css("display","inline");
    }
    $("#closeMod").click(function(){
        $(".addTask, .modale_cover").css("display","none");
    });


    function getTasks(){
        document.getElementById("getProjs").innerHTML = ``;
        let sno = 0;
        $.ajax({
            type: 'POST',
            url: '../API/TASK/GET.php',
            data: {
                p_id: projectId
            },
            success: function (response) {
                
                response = JSON.parse(response);
                console.log(response);

                for(var items of response){
                    sno++;
                    document.getElementById("getProjs").innerHTML += `
                        <tr style="text-align: center">
                            <td>${sno}</td>
                            <td>${items.title}</td>
                            <td>${items.desc}</td>
                            <td>${items.status}</td>
                            <td>
                                <button style="padding:5px 10px;">Open Project</button>
                            </td>
                        </tr>
                    `;
                }
            },
        })
    }
    getTasks();


    function getMembers(){
        document.getElementById("getMembersHere").innerHTML = ``;
        let sno = 0;
        $.ajax({
            type: 'POST',
            url: '../API/MEMBERS/GET.php',
            data: {
                p_id: projectId
            },
            success: function (response) {
                
                response = JSON.parse(response);
                console.log(response);

                for(var items of response){
                    sno++;
                    document.getElementById("getMembersHere").innerHTML += `
                        <div style="width:100%; padding: 15px 10px; line-height: 25px;">${items.u_id}</div>
                    `;
                }
            },
        })

    }
    getMembers();



    function removeMember(u_id){
        if(confirm("Are you sure want to remove this user?") == true){
            $.ajax({
                type: 'POST',
                url: '../API/MEMBERS/DELETE.php',
                data: {
                    u_id: u_id,
                },
                success: function (response) {
                    getMembers();
                    alert(response);
                },
            });
        }
    }


    function invitemail(){
        
        var emailField = $("#emailing").val();
        var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        
        if( !(emailField == "") ){
            if(emailField.match(mailformat)){
                

                
            $.ajax({
                type: 'POST',
                url: '../API/MAILING/SEND.php',
                data: {
                    mail: emailField,
                    key: " <?php echo $getInfo['project_key']; ?>",
                },
                success: function (response) {
                    getMembers();
                    alert(response);
                },
            });

            $("#emailing").val("");


            }else{
                alert("Please enter valid Email");
            }
        }else{
            alert("Can't leave Email Field Empty");
        }
        
    }

    function seemembers(){
        $(".seeMembers, .modale_cover").css("display","inline");
    }

</script>
</html>